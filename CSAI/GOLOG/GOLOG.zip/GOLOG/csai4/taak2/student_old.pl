:- use_module(library(problog)).

0.85 :: researchTopic(T).
0.75 :: solveTask(T).
0.99 :: sendTask(T).

poss(researchTopic(T),S) :-  not topicResearched(T,S).
poss(solveTask(T),S) :- taskGiven(T,S), not taskSolved(T,S).
poss(sendTask(T),S) :- taskGiven(T,S), taskSolved(T,S). 

topicResearched(T,do(A,S)) :- A = researchTopic(T) ; topicResearched(T,S), not A = researchTopic(T).
taskSolved(T,do(A,S)) :- A = solveTask(T); taskSolved(T,S), not A = solveTask(T).
taskGiven(T,do(A,S)) :- not A = sendTaskS(T), taskGiven(T,S).

do(A,s0) :- poss(A,s0),A.
do(A,do(B,S)) :- poss(A,do(B,S)), A, do(B,S).

% Initial database.
taskGiven(T,s0) :- T = csai ; T = cvision ; T = aplai.
topicResearched(T, s0) :- T = aplai.

