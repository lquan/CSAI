:- use_module(library(problog)).

% Declare nature's choices.
choice(researchTopic(T),C) :- C = researchTopicS(T) ; C = researchTopicF(T).
choice(solveTask(T),C) :- C = solveTaskS(T) ; C = solveTaskF(T).
choice(sendTask(T),C) :- C = sendTaskS(T); C = sendTaskF(T).

0.85 :: researchTopicS(T) ; 0.15 :: researchTopicF(T) <-- true.
0.75 :: solveTaskS(T) ; 0.25 :: solveTaskF(T) <-- true.
0.99 :: sendTaskS(T) ; 0.01 :: sendTaskF(T) <-- true.

% Action precondition and successor state axioms.
poss(researchTopicS(T),S) :- not topicResearched(T,S).
poss(researchTopicF(T),S) :- not topicResearched(T,S).
poss(solveTaskS(T),S) :- taskGiven(T,S), not taskSolved(T,S).
poss(solveTaskF(T),S) :- taskGiven(T,S), not taskSolved(T,S).
poss(sendTaskS(T),S) :- taskGiven(T,S), taskSolved(T,S). 
poss(sendTaskF(T),S) :- taskGiven(T,S), taskSolved(T,S).

topicResearched(T,do(A,S)) :- A = researchTopicS(T) ; not A = researchTopicS(T), topicResearched(T,S).
taskSolved(T,do(A,S)) :- A = solveTaskS(T) ; not A = solveTaskS(T), taskSolved(T,S).
taskGiven(T,do(A,S)) :- not A = sendTaskS(T), taskGiven(T,S).

do(A,s0) :- poss(A,s0),A.
do(A,do(B,S)) :- poss(A,do(B,S)), A, do(B,S).

% Initial database.
taskGiven(T,s0) :- T = csai ; T = cvision ; T = aplai.
topicResearched(T, s0) :- T = aplai.

restoreSitArg(topicResearched(T),S,topicResearched(T,S)).
restoreSitArg(taskSolved(T),S,taskSolved(T,S)).
restoreSitArg(taskGiven(T),S,taskGiven(T,S)).

stDo(nil,P,S,S) :- problog_exact(S,P,_).
stDo(A : B,P,S1,S2) :- stochastic(A),
   (not (choice(A,C), poss(C,S1)), !,  % Program can't continue.
   S2 = S1, stDo(nil,P,S1,S2);         % Create a leaf.
   choice(A,C), once(poss(C,S1)),
   stDo(B,P,do(C,S1),S2)).
stDo((A : B) : C,P,S1,S2) :- stDo(A : (B : C),P,S1,S2).

stochastic(A) :- choice(A,N), !.
