% Declare nature's choices.
choice(researchTopic(T),C) :- C = researchTopicS(T) ; C = researchTopicF(T).
choice(solveTask(T),C) :- C = solveTaskS(T) ; C = solveTaskF(T).
choice(sendTask(T),C) :- C = sendTaskS(T); C = sendTaskF(T).
choice(getTaskGrade(T),C) :- C = passTask(T); C = failTask(T).

% Action precondition and successor state axioms.
poss(researchTopicS(T),S) :- not topicResearched(T,S).
poss(researchTopicF(T),S) :- not topicResearched(T,S).
poss(solveTaskS(T),S) :- taskGiven(T,S), not taskSolved(T,S).
poss(solveTaskF(T),S) :- taskGiven(T,S), not taskSolved(T,S).
poss(sendTaskS(T),S) :- taskGiven(T,S), taskSolved(T,S). 
poss(sendTaskF(T),S) :- taskGiven(T,S), taskSolved(T,S).
poss(passTask(T),S) :- taskSolved(T,S), not taskGiven(T,S), not taskGraded(T,S). 
poss(failTask(T),S) :- taskSolved(T,S), not taskGiven(T,S), not taskGraded(T,S).

topicResearched(T,do(A,S)) :- A = researchTopicS(T) ; not A = researchTopicS(T), topicResearched(T,S).
taskSolved(T,do(A,S)) :- A = solveTaskS(T) ; not A = solveTaskS(T), taskSolved(T,S).
taskGiven(T,do(A,S)) :- not A = sendTaskS(T), taskGiven(T,S).
taskGraded(T,do(A,S)) :- not A = passTask(T), not A = failTask(T), taskGraded(T,S) ; A = passTask(T) ; A = failTask(T).
taskPassed(T,do(A,S)) :- not A = passTask(T), not A = failTask(T), taskPassed(T,S) ; A = passTask(T).

% Probabilities.
prob0(researchTopicS(T),researchTopic(T),S,0.85).
prob0(researchTopicF(T),researchTopic(T),S,0.15).
prob0(solveTaskS(T),solveTask(T),S,0.75). 
prob0(solveTaskF(T),solveTask(T),S,0.25).  
prob0(sendTaskS(T),sendTask(T),S,0.99).
prob0(sendTaskF(T),sendTask(T),S,0.01).
prob0(passTask(T),getTaskGrade(T),S,Pr) :- topicResearched(T,S), Pr = 0.9 ; not topicResearched(T,S), Pr = 0.5.
prob0(failTask(T),getTaskGrade(T),S,Pr) :- topicResearched(T,S), Pr = 0.1 ; not topicResearched(T,S), Pr = 0.5.

% Initial database.
taskGiven(T,s0) :- T = csai ; T = cvision ; T = aplai.
topicResearched(T, s0) :- T = aplai.

restoreSitArg(topicResearched(T),S,topicResearched(T,S)).
restoreSitArg(taskSolved(T),S,taskSolved(T,S)).
restoreSitArg(taskGiven(T),S,taskGiven(T,S)).
restoreSitArg(taskGraded(T),S,taskGraded(T,S)).
restoreSitArg(taskPassed(T),S,taskPassed(T,S)).

%%stDo(researchTopic(csai):solveTask(csai):sendTask(csai):nil,P,s0,S).
