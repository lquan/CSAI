:- use_module(library(problog)).

% Declare nature's choices.

choice(researchTopic(T),C) :- C = researchTopicS(T) ; C = researchTopicF(T).
choice(solveTask(T),C) :- C = solveTaskS(T) ; C = solveTaskF(T).
choice(sendTask(T),C) :- C = sendTaskS(T); C = sendTaskF(T).
choice(gradeTask(T),C) :- C = passTask(T); C = failTask(T).

passProb(Pr,T,S) :- topicResearched(T,S), Pr = 0.9 ; not topicResearched(T,S), Pr = 0.5.

0.85 :: researchTopicS(T) ; 0.15 :: researchTopicF(T) <-- true.
0.75 :: solveTaskS(T) ; 0.25 :: solveTaskF(T) <-- true.
0.99 :: sendTaskS(T) ; 0.01 :: sendTaskF(T) <-- true.
Pr :: passTask(T) ; (PrB) :: failTask(T) <-- passProb(Pr,T), PrB is 1-Pr.

% 

% Action precondition and successor state axioms.
poss(researchTopicS(T),S) :- not topicResearched(T,S).
poss(researchTopicF(T),S) :- not topicResearched(T,S).
poss(solveTaskS(T),S) :- taskGiven(T,S), not taskSolved(T,S).
poss(solveTaskF(T),S) :- taskGiven(T,S), not taskSolved(T,S).
poss(sendTaskS(T),S) :- taskGiven(T,S), taskSolved(T,S). 
poss(sendTaskF(T),S) :- taskGiven(T,S), taskSolved(T,S).
poss(passTask(T),S) :- taskSolved(T,S), not taskGiven(T,S), not taskGraded(T,S). 
poss(failTask(T),S) :- taskSolved(T,S), not taskGiven(T,S), not taskGraded(T,S).

topicResearched(T,do(A,S)) :- A = researchTopicS(T) ; not A = researchTopicS(T), topicResearched(T,S).
taskSolved(T,do(A,S)) :- A = solveTaskS(T) ; not A = solveTaskS(T), taskSolved(T,S).
taskGiven(T,do(A,S)) :- not A = sendTaskS(T), taskGiven(T,S).
taskGraded(T,do(A,S)) :- not A = passTask(T), not A = failTask(T), taskGraded(T,S) ; A = passTask(T) ; A = failTask(T).

% Probabilities.
%prob0(researchTopicS(T),researchTopic(T),S,0.85).
%prob0(researchTopicF(T),researchTopic(T),S,0.15).
%prob0(solveTaskS(T),solveTask(T),S,0.75). 
%prob0(solveTaskF(T),solveTask(T),S,0.25).  
%prob0(sendTaskS(T),sendTask(T),S,0.99).
%prob0(sendTaskF(T),sendTask(T),S,0.01).
%prob0(passTask(T),getTaskGrade(T),S,Pr) :- topicResearched(T,S), Pr = 0.9 ; not topicResearched(T,S), Pr =0.5.
%prob0(failTask(T),getTaskGrade(T),S,Pr) :- topicResearched(T,S), Pr = 0.1; not topicResearched(T,S), Pr=0.5.


do(A,s0) :- poss(A,s0),A.
do(A,do(B,S)) :- poss(A,do(B,S)), A, do(B,S).

% Initial database.
taskGiven(T,s0) :- T = csai ; T = cvision ; T = aplai.
topicResearched(T, s0) :- T = aplai.

restoreSitArg(topicResearched(T),S,topicResearched(T,S)).
restoreSitArg(taskSolved(T),S,taskSolved(T,S)).
restoreSitArg(taskGiven(T),S,taskGiven(T,S)).
restoreSitArg(taskGraded(T),S,taskGraded(T,S)).

stDo(nil,P,S,S) :- problog_exact(S,P,_).
stDo(A : B,P,S1,S2) :- stochastic(A),
   (not (choice(A,C), poss(C,S1)), !,  % Program can't continue.
    S2 = S1, P = 1 ;                   % Create a leaf.
  % once is an Eclipse Prolog built-in. once(G) succeeds the first time
  % G succeeds, and never tries again under backtracking. We use it here
  % to prevent stDo from generating the same leaf situation more than
  % once, when poss has multiple solutions.
    choice(A,C), once(poss(C,S1)), % problog_exact(C,P1,_),% prob(C,A,S1,P1),
    stDo(B,P,do(C,S1),S2)). %, P is P1 * P2 ).
stDo((A : B) : C,P,S1,S2) :- stDo(A : (B : C),P,S1,S2).

stochastic(A) :- choice(A,N), !.
