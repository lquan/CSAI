% Philippe Tanghe & Li Quan
% 2011

% TTSA algoritme
% gebruik testTTSA om ttsa op te starten met parameters naar keuze
% ttsa schrijft resultaten weg in tekstbestand experiments.txt
% deze kunnen gebruikt worden voor postprocessing

% opmerking: de uitvoering kan op elk moment afgebroken worden met ctrl-c