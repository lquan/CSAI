function [ y ] = myFun( v )
%MYFUN This is the sublinear function f discussed on p 9

y = 1 + sqrt(v).*log(v)/2; 
 

end

